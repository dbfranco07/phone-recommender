from phone_specs_scraper import get_full_specs_for_phone
from bs4 import BeautifulSoup
import requests
import pandas as pd
from datetime import datetime

datetime.now().strftime('%Y-%m-%d %H:%M:%S')

get_full_specs_for_phone("https://www.pinoytechnoguide.com/smartphones/oppo-a18")

html = 'https://www.pinoytechnoguide.com/smartphones/oppo-a18'
soup = BeautifulSoup(requests.get(html).text, 'lxml')

spec_list = (
    soup
    .find('tbody')
    .find_all('tr')
)

for spec in spec_list:
    # print(spec.text)

    spec_list = list(filter(None, spec))
    print(spec_list)


data = pd.read_csv('phone_specs_raw.csv')
data.sort_values('timestamp').head(5)

date_strs = ["June 30, 2021", "September 2022"]

def unify_date_format(date_str):
    # Try parsing with day included
    try:
        return datetime.strptime(date_str, "%B %d, %Y")
    except ValueError:
        # Parsing failed, try parsing without day, defaulting to the first of the month
        try:
            return datetime.strptime(date_str, "%B %Y").replace(day=1)
        except ValueError as e:
            # Handle unexpected formats or other parsing issues
            print(f"Error parsing date: {e}")
            return None
        
date_strs = ["June 30, 2021", "September 2022"]

unified_dates = [unify_date_format(date_str) for date_str in date_strs]
for original, unified in zip(date_strs, unified_dates):
    print(f"Original: {original}, Unified: {unified.strftime('%B %d, %Y')}")

